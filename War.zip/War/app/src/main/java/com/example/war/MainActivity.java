package com.example.war;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity<s1> extends AppCompatActivity {
    Button button1, button2, button3, button4;
    FragmentManager fragmentManager;
    ImageView imageView1, imageView2, imageView3, imageView4;

    int s = 1;
    
    String v = "1";
//    int t = 1;
//    int a = 1;

//    SharedPreferences sharedPreferences;
//    static final String data_base = "data_base";
//    String fase = "fasekee";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
//        sharedPreferences = getSharedPreferences( "data_base", Context.MODE_PRIVATE );

        button1 = findViewById( R.id.sod );
        button2 = findViewById( R.id.vib );
        button3 = findViewById( R.id.tee );
        button4 = findViewById( R.id.ato );
        imageView1 = findViewById( R.id.isod );
        imageView2 = findViewById( R.id.ivib );
        imageView3 = findViewById( R.id.itee );
        imageView4 = findViewById( R.id.iato );

//        String s1 = sharedPreferences.getString( "fase", "" );
//        if (s1.equals( "es" )) {
//            imageView1.setVisibility( View.VISIBLE );
//
//        } else if (s1.equals( "fs" )) {
//            imageView1.setVisibility( View.INVISIBLE );
//        }
        button1.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (s == 1) {
                    imageView1.setVisibility( View.VISIBLE );
                    imageView2.setVisibility( View.VISIBLE );
//                    SharedPreferences.Editor editor = sharedPreferences.edit();
//                    editor.putString( "fase", "es" );
//                    editor.apply();
                    s++;
                } else {
                    imageView1.setVisibility( View.INVISIBLE );
                    imageView2.setVisibility( View.INVISIBLE );
//                    SharedPreferences.Editor editor = sharedPreferences.edit();
//                    editor.putString( "fase", "fs" );
//                    editor.apply();
                    s--;
                }
            }
        } );
        
        button2.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( MainActivity.this, Main2Activity.class );
                startActivity( intent );
            }
        } );

        button3.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragmentManager = getSupportFragmentManager()
            }
        } );


    }

    @Override
    protected void onStart() {
        super.onStart();
        imageView2.setVisibility( View.VISIBLE );
    }
}
